function r = rad2deg(d)
	r = d * 180 /  pi;
