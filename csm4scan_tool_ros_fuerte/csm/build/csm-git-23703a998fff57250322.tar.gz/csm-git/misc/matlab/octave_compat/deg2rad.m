function r = deg2rad(d)
	r = pi * d / 180;
