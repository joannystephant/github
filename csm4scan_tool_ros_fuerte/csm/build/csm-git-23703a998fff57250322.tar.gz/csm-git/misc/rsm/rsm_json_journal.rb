
module JSON_journal
	def jj_context_enter(name)

	end
	
	def jj_context_exit()
		
	end
	
	def jj_loop_enter(name)
		
	end
	
	def jj_loop_iteration(name)
		
	end
	
	def jj_loop_exit()
		
	end
	# 
	# void jj_add_int(const char*name, int);
	# void jj_add_double(const char*name, double);
	# void jj_add_double_array(const char*name, double*,int);
	# void jj_add_int_array(const char*name, int*,int);
	# void jj_add(const char*name, JO);
end