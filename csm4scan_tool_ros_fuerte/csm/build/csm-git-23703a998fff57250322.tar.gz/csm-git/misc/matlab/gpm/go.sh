../scripts/collate.rb < gpm.m > test_gpm.m  
pdflatex test

